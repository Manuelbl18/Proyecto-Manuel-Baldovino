package controlador;

public class LocalidadController {

}
