package modelo;

public class Localidad {

}
