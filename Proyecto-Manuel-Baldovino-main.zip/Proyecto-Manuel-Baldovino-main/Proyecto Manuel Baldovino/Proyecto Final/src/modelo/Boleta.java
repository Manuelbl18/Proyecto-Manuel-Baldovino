package modelo;

public class Boleta {

}
